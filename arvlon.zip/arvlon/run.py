import http.server
import socketserver
import webbrowser
import os

PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

def run_server():
    os.chdir(DIRECTORY)
    handler = CustomHandler
    
    with socketserver.TCPServer(("", PORT), handler) as httpd:
        url = f"http://localhost:{PORT}"
        print("=" * 60)
        print(" 🛋️  ARVLON Furniture - Local Development Server")
        print("=" * 60)
        print(f" جاري تشغيل الموقع محلياً على الرابط: {url}")
        print(" اضغط على المفاتيح (Ctrl + C) في لوحة المفاتيح لإيقاف السيرفر.")
        print("=" * 60)
        
        webbrowser.open(url)
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n🛑 تم إيقاف السيرفر بنجاح. شكراً لاستخدامك أرفلون!")

if __name__ == "__main__":
    run_server()
