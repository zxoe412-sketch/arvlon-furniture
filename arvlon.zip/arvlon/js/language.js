/**
 * ARVLON Furniture - i18n Language Manager
 */

const translations = {
    ar: {
        nav_home: "الرئيسية",
        nav_products: "الأثاث والمنتجات",
        nav_categories: "التصنيفات",
        nav_about: "من نحن",
        nav_contact: "تواصل معنا",
        hero_title: "الفخامة والجمال في كل تفصيل",
        hero_subtitle: "نصنع لك أثاثاً يجمع بين الأصالة والعصرية، ليكون بيتك تحفة فنية تتوارثها الأجيال في اليمن.",
        hero_btn: "استكشف المنتجات",
        cat_title: "تصنيفات الأثاث",
        featured_title: "منتجاتنا المميزة",
        why_title: "لماذا تختار أرفلون؟",
        feat_1_title: "جودة استثنائية",
        feat_1_desc: "نستخدم أفضل أنواع الأخشاب والأقمشة العالمية المعتمدة.",
        feat_2_title: "تصاميم حصرية",
        feat_2_desc: "لمسات إبداعية تناسب الذوق الفاخر والمجالس الأنيقة.",
        feat_3_title: "خدمة توصيل وتركيب",
        feat_3_desc: "فريق احترافي يضمن وصول وتجهيز أثاثك بكل عناية.",
        btn_inquire_wa: "استفسر عبر واتساب",
        btn_details: "التفاصيل",
        contact_title: "معلومات التواصل والعنوان",
        address_text: "شارع الأربعين، أمام سور الرئاسة، صنعاء، اليمن.",
        phone_text: "+967 777 487 666",
        rights_reserved: "جميع الحقوق محفوظة © 2026 أرفلون للأثاث (ARVLON Furniture)",
        filter_all: "الكل",
        filter_bedroom: "غرف النوم",
        filter_living: "غرف المعيشة",
        filter_majlis: "الكنب والمجالس",
        filter_dining: "طاولات الطعام",
        filter_kids: "غرف الأطفال",
        filter_office: "المكاتب"
    },
    en: {
        nav_home: "Home",
        nav_products: "Furniture & Products",
        nav_categories: "Categories",
        nav_about: "About Us",
        nav_contact: "Contact Us",
        hero_title: "Luxury & Elegance in Every Detail",
        hero_subtitle: "Crafting furniture that blends heritage and modern luxury for your home in Yemen.",
        hero_btn: "Explore Collection",
        cat_title: "Furniture Categories",
        featured_title: "Featured Products",
        why_title: "Why Choose ARVLON?",
        feat_1_title: "Exceptional Quality",
        feat_1_desc: "We use the finest global woods and luxury upholstery fabrics.",
        feat_2_title: "Exclusive Designs",
        feat_2_desc: "Creative touches tailored for high-end lifestyles and elegance.",
        feat_3_title: "Delivery & Assembly",
        feat_3_desc: "Professional crew ensuring safe delivery and expert setup.",
        btn_inquire_wa: "Inquire via WhatsApp",
        btn_details: "Details",
        contact_title: "Contact & Location",
        address_text: "Forty St., Opposite Presidential Wall, Sana'a, Yemen.",
        phone_text: "+967 777 487 666",
        rights_reserved: "All Rights Reserved © 2026 ARVLON Furniture",
        filter_all: "All",
        filter_bedroom: "Bedrooms",
        filter_living: "Living Rooms",
        filter_majlis: "Majlis & Sofas",
        filter_dining: "Dining Tables",
        filter_kids: "Kids Rooms",
        filter_office: "Offices"
    }
};

function setLanguage(lang) {
    localStorage.setItem('arvlon_lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (translations[lang] && translations[lang][key]) {
            element.innerText = translations[lang][key];
        }
    });

    const langBtn = document.getElementById('langToggleBtn');
    if (langBtn) {
        langBtn.innerText = lang === 'ar' ? 'English' : 'عربي';
    }

    if (typeof renderProducts === 'function') {
        renderProducts();
    }
}

function toggleLanguage() {
    const currentLang = localStorage.getItem('arvlon_lang') || 'ar';
    const newLang = currentLang === 'ar' ? 'en' : 'ar';
    setLanguage(newLang);
}

document.addEventListener('DOMContentLoaded', () => {
    const savedLang = localStorage.getItem('arvlon_lang') || 'ar';
    setLanguage(savedLang);
});
