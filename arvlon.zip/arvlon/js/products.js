/**
 * ARVLON Furniture - Product Catalog Database
 * يحتوي هذا الملف على المنتجات التجريبية القابلة للتعديل والزيادة والحذف بكل سهولة.
 */

const productsData = [
    {
        id: 1,
        title_ar: "طقم كنب ملكي أرفلون",
        title_en: "ARVLON Royal Sofa Set",
        category: "living",
        price_yr: "حسب الطلب / اتصل بنا",
        price_en: "Upon Request",
        image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80",
        description_ar: "طقم كنب فاخر مصنوع من أجود أنواع الخشب الطبيعي والقماش المخملي الراقي لمجالس وهال فاخرة.",
        description_en: "Luxury sofa set made from prime natural wood and high-end velvet fabric."
    },
    {
        id: 2,
        title_ar: "غرفة نوم ماستر مودرن",
        title_en: "Modern Master Bedroom Set",
        category: "bedroom",
        price_yr: "حسب المقاس والطلب",
        price_en: "Custom Pricing",
        image: "https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=800&q=80",
        description_ar: "تصميم عصري متكامل يتضمن سريراً مزدوجاً، وخزانة ملابس، وطاولتين جانبيتين مع تسريحة فخمة.",
        description_en: "Modern bedroom set featuring double bed, wardrobe, side tables, and elegant vanity."
    },
    {
        id: 3,
        title_ar: "طاولة طعام 8 كراسي",
        title_en: "Dining Table 8 Chairs",
        category: "dining",
        price_yr: "اتصل للتفاصيل",
        price_en: "Call for Pricing",
        image: "https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=800&q=80",
        description_ar: "طاولة طعام راقية من الرخام والخشب الصلب مزودة بـ 8 كراسي مريحة للغاية ومصممة بأعلى جودة.",
        description_en: "Elegant dining table made of marble and solid wood with 8 premium comfortable chairs."
    },
    {
        id: 4,
        title_ar: "مجلس عربي فاخر",
        title_en: "Luxury Arabic Majlis",
        category: "majlis",
        price_yr: "تأثيث حسب المساحة",
        price_en: "Custom Fitting",
        image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
        description_ar: "تصميم مجلس يمني وعربي فاخر يجمع بين التراث والأصالة والتصاميم الحديثة والراحة الفائقة.",
        description_en: "Authentic and luxurious Arabic majlis combining heritage, modernity, and ultimate comfort."
    },
    {
        id: 5,
        title_ar: "طقم مكتب تنفيذي",
        title_en: "Executive Office Suite",
        category: "office",
        price_yr: "حسب المواصفات",
        price_en: "Custom Specs",
        image: "https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=800&q=80",
        description_ar: "مكتب فخم للإداريين والقيادات مع كرسي مريح وطاولة اجتماعات ملحقة.",
        description_en: "Executive office suite designed for leadership with ergonomic seating and meeting table."
    },
    {
        id: 6,
        title_ar: "غرفة أطفال متكاملة",
        title_en: "Kids Bedroom Set",
        category: "kids",
        price_yr: "اتصل للاستفسار",
        price_en: "Inquire for price",
        image: "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
        description_ar: "غرفة أطفال آمنة، مبهجة، وذات جودة عالية تدوم طويلاً وتناسب جميع الأعمار.",
        description_en: "Safe, vibrant, high-quality kids bedroom furniture designed for comfort and longevity."
    }
];

// Helper Function: WhatsApp Order Generator
function getWhatsAppLink(productTitle = "") {
    const phone = "967777487666";
    const currentLang = localStorage.getItem('arvlon_lang') || 'ar';
    let message = "";
    
    if (productTitle) {
        message = currentLang === 'ar' 
            ? `مرحباً أرفلون للأثاث، أود الاستفسار عن تفاصيل وسعر المنتج: (${productTitle})` 
            : `Hello ARVLON Furniture, I would like to inquire about: (${productTitle})`;
    } else {
        message = currentLang === 'ar' 
            ? `مرحباً أرفلون للأثاث، أود الاستفسار عن خدماتكم والمنتجات المتاحة.` 
            : `Hello ARVLON Furniture, I would like to inquire about your products.`;
    }

    return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
