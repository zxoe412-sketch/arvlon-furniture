/**
 * ARVLON Furniture - Main Interactive Functions
 */

document.addEventListener('DOMContentLoaded', () => {
    // Mobile Nav Toggle
    const mobileBtn = document.getElementById('mobileMenuToggle');
    const navLinks = document.getElementById('navLinks');

    if (mobileBtn && navLinks) {
        mobileBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }

    // Modal Events
    const modal = document.getElementById('productModal');
    const closeModalBtn = document.getElementById('closeModalBtn');

    if (closeModalBtn && modal) {
        closeModalBtn.addEventListener('click', () => {
            modal.classList.remove('active');
        });

        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    }
});

// Render Modal Details
function openProductModal(productId) {
    const product = productsData.find(p => p.id === productId);
    if (!product) return;

    const lang = localStorage.getItem('arvlon_lang') || 'ar';
    const modal = document.getElementById('productModal');
    const modalContent = document.getElementById('modalDetailsBody');

    const title = lang === 'ar' ? product.title_ar : product.title_en;
    const desc = lang === 'ar' ? product.description_ar : product.description_en;
    const price = lang === 'ar' ? product.price_yr : product.price_en;
    const waLink = getWhatsAppLink(title);

    modalContent.innerHTML = `
        <div style="width:100%;">
            <img src="${product.image}" alt="${title}" style="width:100%; height:280px; object-fit:cover; border-radius:6px;" />
        </div>
        <div style="display:flex; flex-direction:column; justify-content:center;">
            <h2 style="color:var(--secondary-color); margin-bottom:10px;">${title}</h2>
            <p style="color:var(--primary-dark); font-weight:bold; margin-bottom:15px; font-size:1.1rem;">${price}</p>
            <p style="color:var(--text-muted); margin-bottom:20px;">${desc}</p>
            <a href="${waLink}" target="_blank" class="btn-whatsapp-inquiry" style="text-decoration:none; text-align:center;">
                <i class="fab fa-whatsapp"></i> ${lang === 'ar' ? 'طلب أو استفسار عبر واتساب' : 'Inquire on WhatsApp'}
            </a>
        </div>
    `;

    modal.classList.add('active');
}
